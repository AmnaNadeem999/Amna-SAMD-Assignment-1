package com.example.myschedule;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.Serializable;

public class SignUpActivity extends AppCompatActivity implements Serializable {
    Button signup;
    EditText txtfullname,txtage,txtemail,txtpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        signup=(Button)findViewById(R.id.btnSign);
        txtfullname=(EditText) findViewById(R.id.txtfullname);
        txtage=(EditText) findViewById(R.id.txtage);
        txtemail=(EditText) findViewById(R.id.txtemail);
        txtpassword=(EditText) findViewById(R.id.txtpassword);
    }
    public class user{
        String name,age,email;
        user(){
            name=txtfullname.getText().toString();
            age=txtage.getText().toString();
            email=txtemail.getText().toString();
        }
    }
    public void onBtnSignClicked(View view){

        if(txtfullname.getText().toString().equals("")||txtage.getText().toString().equals("")||txtemail.getText().toString().equals("")||txtpassword.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Incomplete Credentials",Toast.LENGTH_SHORT).show();
        }
        else {
          /* MainActivity.status=true;
            MainActivity.Authentication log = new MainActivity.Authentication();
            log.username=txtemail.getText().toString();
            log.password=txtpassword.getText().toString();*/
            Toast.makeText(getApplicationContext(), "Sign up Successfully!",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
        //  intent.putExtra("obj", (Serializable) log);
            startActivity(intent);
        }
    }
}