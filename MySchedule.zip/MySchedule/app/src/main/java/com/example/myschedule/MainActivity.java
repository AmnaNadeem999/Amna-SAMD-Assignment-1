package com.example.myschedule;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {
    public static boolean status=false;
    EditText email, pass;
    Button login,signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email=(EditText) findViewById(R.id.txtemail);
        pass=(EditText) findViewById(R.id.txtpass);
        login=(Button) findViewById(R.id.btnLogin);
        signup=(Button) findViewById(R.id.btnSignUp);
    }
    public static class Authentication{
        public static String username="amnabahrian999@gmail.com", password="1";
    }
    public void onbtnLoginClicked(View view)
    {
            Authentication log=new Authentication();
            if (email.getText().toString().equals(log.username) && pass.getText().toString().equals(log.password)) {
                Intent intent = new Intent(this, DashboardActivity.class);
                startActivity(intent);
            } else if (email.getText().toString().equals("") || pass.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Fill the above fields", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
    }
    public void onbtnSignUpClicked(View view)
    {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }
}